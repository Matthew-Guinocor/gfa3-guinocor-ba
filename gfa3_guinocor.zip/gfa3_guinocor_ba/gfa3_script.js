// Formative Assessment 3

    // Variable Declaration
        // Function uses ceil() instead of round() to round up to the nearest integer.
    let num1 = Math.ceil(Math.random() * 20);
	let num2 = Math.ceil(Math.random() * 20);
	let num3 = Math.ceil(Math.random() * 20);

    // Results
        // I used &#(Number) to print out the emojis.
    document.getElementById("apple").innerHTML = "&#127822 | Apple: <b>" + num1 + "</b> <br>";
    document.getElementById("banana").innerHTML = "&#127820 | Banana: <b>" + num2 + "</b> <br>";
    document.getElementById("orange").innerHTML = "&#127818 | Orange: <b>" + num3 + "</b> <br>";

    // Special Conditions
        // Condition 1: Maximum Value
       if(num1 > num2 && num1 > num3){
        document.getElementById("h_score").innerHTML = "Most Harvested Fruit: &#127822 | Apple <b> (" +num1+ ") </b> <br>";
       } 
       else if(num2 > num1 && num2 > num3){
        document.getElementById("h_score").innerHTML = "Most Harvested Fruit: &#127820 | Banana <b> (" +num2+ ") </b> <br>";
       }
       else if(num3 > num1 && num3 > num2){
        document.getElementById("h_score").innerHTML = "Most Harvested Fruit: &#127818 | Orange <b> (" +num3+ ") </b> <br>";
       }
       else if(num1 == num2 && num1 > num3){
        document.getElementById("h_score").innerHTML = "Most Harvested Fruit: Apple and Banana <b> (" +num1+ ") </b> <br>";
       }
       else if(num1 == num3 && num1 > num2){
        document.getElementById("h_score").innerHTML = "Most Harvested Fruit: Apple and Orange <b> (" +num1+ ") </b> <br>";
       }
       else if(num2 == num3 && num2 > num1){
        document.getElementById("h_score").innerHTML = "Most Harvested Fruit: Banana and Orange <b> (" +num2+ ") </b> <br>";
       }
       else{
        document.getElementById("h_score").innerHTML = "Most Harvested Fruit: Apple, Banana, and Orange <b> (" +num1+ ") </b> <br>";
       }

        // Condition 2: Random Letter
        let letter = String.fromCharCode(64 + num1);
        document.getElementById("letters").innerHTML = "Best harvester for Oranges starts with the letter: <b> " +letter+ "</b> <br>";

        if(letter == "@"){
        document.getElementById("letters").innerHTML = "Best harvester for Oranges starts with the letter: <b> A </b> <br>";
        }
		

        // Condition 3: Time Display
        let minutes = num2 * num3;
		let hours = Math.floor(minutes / 60);
		let remMin = minutes % 60;
		document.getElementById("time").innerHTML = "Time taken to harvest oranges: <b> (" +minutes+ " mins) </b> | " +hours+ " hr " +remMin+ " min";